import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InvitesRoutingModule } from './invites-routing.module';
import { InvitesComponent } from './invites.component';
import { GridAllModule } from '@syncfusion/ej2-angular-grids'; 
import { DateRangePickerModule } from '@syncfusion/ej2-angular-calendars';

@NgModule({
  declarations: [InvitesComponent],
  imports: [
    CommonModule,
    InvitesRoutingModule,
    GridAllModule,
    DateRangePickerModule
  ]
})
export class InvitesModule { }
