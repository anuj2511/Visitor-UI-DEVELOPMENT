import { Component, OnInit, ViewChild,AfterViewInit } from '@angular/core';
import { data } from '../data';
import { PageSettingsModel,FilterSettingsModel,ToolbarItems,GridComponent } from '@syncfusion/ej2-angular-grids';
import * as $ from "jquery";

@Component({
  selector: 'app-invites',
  templateUrl: './invites.component.html',
  styleUrls: ['./invites.component.scss']
})
export class InvitesComponent implements OnInit ,AfterViewInit{

  public data: object[];
  public pagesettings: PageSettingsModel;
  public filtersettings: FilterSettingsModel;
  public toolbarOptions: ToolbarItems[];
  public columns: any
  // public month: number = new Date().getMonth();
  // public fullYear: number = new Date().getFullYear();
  public start: ""
  public end: "";
  @ViewChild('grid') public grid: GridComponent;
  //public a = parseInt($("#sizeChange").val());
  total_visits
  invited_visitors: number;
  images=[];
  constructor() { }

  ngOnInit(): void {
    this.data = data;
    for(let i in data){
      this.images[i] = data[i].Image
    }
    this.filtersettings = { ignoreAccent: true }
    this.toolbarOptions = ['Search', 'ColumnChooser'];
    this.pagesettings = { pageSizes: ['2', '3', 'All'] }
    $("#date1").val(new Date().toLocaleDateString())
    //this.columns=[{field:"EmployeeID",fieldName :"EmployeeID"}]
    //this.grid.refreshColumns();
    for (var i = 1; i <= data.length; i++) {
      if ((data.length > 10 && i == 10) || (data.length < 10 && i == data.length)) {
        $("#sizeChange").append("<option value=" + i + " selected>" + i + "</option>");
      } else {
        $("#sizeChange").append("<option value=" + i + ">" + i + "</option>");
      }
    }
    this.total_visits = data.length;//data.total_visits
    this.invited_visitors = data.length;//data.invited_visitors
  }
  ngAfterViewInit(): void {
    this.pagesettings = { pageSize: data.length > 10 ? 10 : data.length }
  }
  changeSize() {
    let a:any=$("#sizeChange").val(); 
    this.pagesettings = { pageSize: parseInt(a) }
  }
  ranged(){
    var startDate =new Date($('#daterangepicker_input').val().toString().split("-")[0]);
    var endDate = new Date($('#daterangepicker_input').val().toString().split("-")[1]);
    var resultProductData = data.filter(a => {
      var date = new Date(a.date);
      return (date >= startDate && date <= endDate);
    });
    this.data = resultProductData;
  }

}
