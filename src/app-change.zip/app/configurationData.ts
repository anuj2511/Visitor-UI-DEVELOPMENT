
export let configurationData: any= [  
    {
        Field:"Take Photo", FieldType:"-",Mandatory:true, Actions:{"action1": "pencil_gray.png","action2": "action2.png"}
    },  
    {
        Field:"Email", FieldType:"text field",Mandatory:true,Actions:{"action1": "pencil_gray.png","action2": "noAction.png"}
    },
    {
        Field:"Full Name", FieldType:"text field",Mandatory:false,Actions:{"action1": "pencil_gray.png","action2": "noAction.png"}
    },
    {
        Field:"NRIC/FIN/Passport No", FieldType:"text field",Mandatory:true,Actions:{"action1": "pencil_gray.png","action2": "action2.png"}
    },
    {
        Field:"Mobile No", FieldType:"text field",Mandatory:false,Actions:{"action1": "pencil_gray.png","action2": "action2.png"}
    },
    {
        Field:"Person to Visit", FieldType:"text field",Mandatory:true,Actions:{"action1": "pencil_gray.png","action2": "action2.png"}
    },
    {
        Field:"Purpose of Visit", FieldType:"text field",Mandatory:false,Actions:{"action1": "pencil_gray.png","action2": "action2.png"}
    }
	];