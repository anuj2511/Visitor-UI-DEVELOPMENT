
export let data: any= [
    {
        Image:"Abhay.png", FullName:"Abhay Singh",Email:"abhay@mail.com",ContactNo:9374283485,ExpectedTime:'9:00am',ArrivalTime:'09:05am',date:"2019-09-04"
    },
	{
        Image:"FrankGavin.png",FullName:"Frank Gavin",Email:"frank@mail.com",ContactNo:9373283485,ExpectedTime:'9:00am',ArrivalTime:'09:59am',date:"2019-08-08"
    },
	{
        Image:"JessicaParker.png",FullName:"Jessica Parker",Email:"jess@mail.com",ContactNo:9574283485,ExpectedTime:'9:00am',ArrivalTime:'05:05am',date:"2021-08-04"
    },
	{
        Image:"OscarParker.png",FullName:"Oscar Parker",Email:"osca32@mail.com",ContactNo:8574283485,ExpectedTime:'9:00am',ArrivalTime:'09:05am',date:"2020-08-04"
    }
	];